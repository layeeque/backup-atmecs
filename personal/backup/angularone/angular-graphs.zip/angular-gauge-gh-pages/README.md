# angular-gauge
This is a small Angular-Directive for plain SVG gauges/doughnut charts.
Demo: http://bombshock.github.io/angular-gauge/

